package com.demo.model;

public class Employee {
	
	private int id;
	private String ename;
	private int eage;
	private double esal;
	
	public Employee() {
		
	}
	
	public Employee(String ename, int eage, double esal) {
		super();
		this.ename = ename;
		this.eage = eage;
		this.esal = esal;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEage() {
		return eage;
	}
	public void setEage(int eage) {
		this.eage = eage;
	}
	public double getEsal() {
		return esal;
	}
	public void setEsal(double esal) {
		this.esal = esal;
	}
	
	
	
	

}
