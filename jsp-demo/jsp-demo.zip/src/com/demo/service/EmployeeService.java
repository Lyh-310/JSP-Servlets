package com.demo.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.demo.model.Employee;

public class EmployeeService {
	
	Connection con;
	
	public EmployeeService() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dec2017", "root", "password");

		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public int insert(Employee emp) {
		try{
			PreparedStatement ps = con.prepareStatement("insert into employee (name, age, salary) values(?,?,?)");
			ps.setString(1, emp.getEname());
			ps.setInt(2, emp.getEage());
			ps.setDouble(3, emp.getEsal());
			int x = ps.executeUpdate();
			return x;
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}

}
